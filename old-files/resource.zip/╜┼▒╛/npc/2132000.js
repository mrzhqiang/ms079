/* Author: aaroncsn(MapleSea Like)(Incomplete)
	NPC Name: 		Kanderun
	Map(s): 		Elin Forest:Entrance to Rocky Mountain(300010400)
	Description: 		Unknown
*/

function start(){
	cm.sendOk("Hmmm! For you to make your way here, far away from the Camp, you must be one strong individual. Let's explore new areas and find a place to establish our own town!!");
	cm.dispose();
	}