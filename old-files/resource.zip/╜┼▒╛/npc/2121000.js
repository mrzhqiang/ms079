function action(mode, type, selection) {
    if (mode == 1) {
	cm.warp(910000000);
	cm.dispose();
	}
 }