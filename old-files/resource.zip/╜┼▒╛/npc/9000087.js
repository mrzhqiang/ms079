var status = -1;

function action(mode, type, selection) {
    cm.warp(910000000);
	cm.saveReturnLocation("FREE_MARKET");
	cm.dispose();
}