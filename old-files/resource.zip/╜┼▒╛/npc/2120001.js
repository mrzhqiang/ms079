function start() {
	if (cm.getMapId() == 910000000) {
		cm.warp(682000000);
                cm.dispose();
	} else { // 682000000
		cm.warp(682000100);
                cm.dispose();
	}
    }