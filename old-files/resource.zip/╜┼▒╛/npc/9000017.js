var status = -1;

function action(mode, type, selection) {
	cm.sendOk("哦，我是多么的爱我的情人节!");
	cm.dispose();
}