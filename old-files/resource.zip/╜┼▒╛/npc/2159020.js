function action(mode, type, selection) {
    cm.sendNext("Haha! FOOLS! Prepare to die!");
    cm.dispose();
}