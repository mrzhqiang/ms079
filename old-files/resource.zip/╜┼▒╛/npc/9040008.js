/* Guild Rank Board */

function start() {
    cm.dispose();
    return;
    cm.displayGuildRanks();
    cm.dispose();
}
