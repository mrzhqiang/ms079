/**
	Mr. Mohammed - El Nath : El Nath Market (211000100)
**/

function start() {
    cm.sendStorage();
    cm.dispose();
}