/* @Author Lerk
 *
 * Armor Statue - Sharenian: Hall of the Knight (990000400)
 * 
 * Guild Quest Stage 2 Info
 */


function action(mode, type, selection) {
    cm.sendOk("翻译如下: \r\n\"对sharenian骑士是骄傲的战士。他们都是强大的武器朗吉弩斯矛和城堡的防御的关键：通过消除他们的平台在这大厅的最高点，他们阻挡入侵者的入口.\"\r\n\r\n似乎有一些东西在英语上蚀刻，几乎没有可读性: \r\n\"邪恶偷走了矛，被锁链锁住了。回到塔上。大的矛，从高处抓起.\"\r\n...很显然，无论是谁想出了它没有太多的时间去生活。可怜的家伙.");
    cm.safeDispose();
}