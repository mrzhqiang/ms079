/**
	Mr. Hong - Victoria Road : Kerning City (103000000)
**/

function start() {
    cm.sendStorage();
    cm.dispose();
}