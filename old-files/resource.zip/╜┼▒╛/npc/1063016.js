function action(mode, type, selection) {
	cm.warp(105040201, 0);
	cm.dispose();
}