/* Author: aaroncsn(MapleSea Like)(Incomplete)
	NPC Name: 		Pam
	Map(s): 		Leafre: Pam's House(240000006)
	Description: 		Unknown
*/

function start(){
	cm.sendOk("Hmmm... baby formula? Don't you think you're past that age?");
	cm.dispose();
	}