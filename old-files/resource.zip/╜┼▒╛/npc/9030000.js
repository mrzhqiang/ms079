function start() {
    cm.openMerchantItemStore();
    cm.dispose();
}

function action(mode, type, selection){
    cm.dispose();
}