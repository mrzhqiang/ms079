/* Author: aaroncsn(MapleSea Like)
	NPC Name: 		Assistant Cheng
	Map(s): 		Ludibrium: Toy Factory Zone 1(220020000)
	Description: 		Unknown
*/

function start(){
	cm.sendNext("Thanks to you, the Toy Factory is running smoothly again. I'm so glad you came to help us out. We've been keeping an extra eye on all of our partys, so don't worry about it. Well then, I need to get back to work!");
	cm.warp(922000000);
	cm.dispose();
	}