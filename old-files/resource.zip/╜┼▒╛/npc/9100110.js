// Unknown Gachapon

function action(mode, type, selection) {
    cm.dispose();
}