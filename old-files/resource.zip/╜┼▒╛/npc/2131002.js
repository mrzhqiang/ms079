/* Author: aaroncsn(MapleSea Like)(Incomplete)
	NPC Name: 		Euryth
	Map(s): 		Elin Forest:Altair Camp(300000000)
	Description: 		Unknown
*/

function start(){
	cm.sendOk("My name is Euryth... As you can see, I am a fairy. People tell me I do not act fairy-like, but... I like making things out of metal objects. Shhh, don't tell this to anyone, but I also like MMA.");
	cm.dispose();
	}