var status = -1;

function action(mode, type, selection) {
	cm.sendNext("I hate cleaning...");
	cm.dispose();
}