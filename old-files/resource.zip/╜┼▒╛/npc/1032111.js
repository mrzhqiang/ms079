/* Author: aaroncsn(MapleSea Like)
	NPC Name: 		Small Trunk
	Map(s): 		Victoria Road : Top of the Tree That Grew (101010103)
	Description: 		A tree
*/

function start() {
	cm.sendOk("A sweet scent of tree bark tickles my nose.");
	cm.dispose();
	}