/* Guild Rank Board */

function action(mode, type, selection) {
    cm.displayGuildRanks();
    cm.dispose();
}