/* 	Garnox - Pet Scientist
	Singapore and NLC
*/


function start() {
    cm.sendOk ("Hi, I'm Garnox the Pet Scientist. Have you heard of the evolution of special pets?");
}

function action() {
    cm.dispose()
}