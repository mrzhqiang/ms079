function start() {
	cm.getMap().killMonster(5090000);
	cm.dispose();
}

function action(mode, type, selection) {
}	