var status = -1;

function action(mode, type, selection) {
    cm.warp(910001000);
	cm.saveReturnLocation("ARDENTMILL");
	cm.dispose();
}