/*
	Yuse - Zipangu : Showa Town (801000000)
*/

function start() {
    cm.sendStorage();
    cm.dispose();
}