function action(mode, type, selection) {
    cm.sendProfessionWindow();
    cm.dispose();
}