function start() {
    cm.warpParty(230000003);	
    cm.dispose();
}